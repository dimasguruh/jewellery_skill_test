Project ini dibuat untuk memenuhi ujian Skill Test dari PT Passion Abadi Jewellery

Cara Menjalankan Aplikasi:

1. Pindahkan atau Checkout Project ini di folder htdocs atau www di xampp/mamp/linux 
2. Export database yang memiliki nama jewellery.sql di database server komputer anda dan beri nama yang sama
3. Ubah base_url jika diperlukan apabila project tidak kompatibel secara routing url di komputer anda
	pengaturan ada di file : jewellery\application\config
4. Apabila ada yang kurang bisa kontak kepada saya.

Terima kasih.