<html>
    <head>
        <title>Soal Tes PT Passion Abadi Jewellery</title>
    </head>
    <body>
        <p>    
            Soal: BUAT LAPORAN PERGERAKAN STOK BARANG JADI (PRODUCT)
        <ol>
            <li>Terdapat 2 macam barang yaitu ProductDJ (product-dj.csv) dan ProductLS (product-ls.csv)</li>
            <li>ProductDJ bisa berasal dari produksi ataupun pembelian</li>
            <li>ProductLS hanya berasal dari pembelian</li>
            <li>Master data barang ada di product-dj.csv dan product-ls.csv</li>
            <li>Tiap barang memiliki SKU yang berbeda, tidak ada SKU yang duplikat, anda harus men-grup kan barang sesuai kategori barang yang di definisikan di soal.</li>
            <li>Terdapat 3 macam transaksi terhadap data barang:</li>
            <li>Pembelian/Produksi: product-dj.csv / buyback-ls.csv, field:</li>
            <li>purchasedt: tgl beli atau tgl selesai produksi</li>
            <li>isproduction=0/1 (0=beli, 1=produksi) hanya ada di productdj</li>
            <li>Buyback: buyback-dj.csv / buyback-ls.csv</li>
            <li>buybackdt: tgl buyback</li>
            <li>Penjualan: sales-dj.csv / sales-ls.csv</li>
            <li>salesdt: tgl penjualan</li>
        <ol>
            
        </p>
        <p>
            Dari data source yang diberikan buatlah report pergerakan stok seperti contoh hasil keluaran di dalam modul PHP menggunakan Codeigniter 3.
            
            Adapun report pergerakan stok menunjukan data pcs, berat barang, nilai barang, dengan data:
            <ol>
                <li>1. Stok awal (join stock-awal-dj/ls.csv dengan product-dj/ls.csv untuk atribut data)</li>
                <li>2. Stok masuk dari pembelian/produksi</li>
                <li>3. Stok masuk dari buyback</li>
                <li>4. Stok keluar untuk penjualan</li>
                <li>5. Stok akhir (Stok awal + pembelian/produksi + buyback - penjualan)</li>
            </ol>

            Format exact dari hasil kerja yang diinginkan dapat dilihat di file ‘EXPECTED RESULT.xlsx’
            Hasil kerja program dan database dibuat di git dan di submit url git nya.
        </p>

        <h3><center><a href="<?php echo base_url('Task/answerFilter')?>">Go to Answer >></a></center></h3>
    </body>
</html>