<html>
    <head>
        <script type="text/javascript">
            function cekform()
            {
                if($('#category').val()==0)
                {
                    alert("Anda Belum Memilih Filter");
                    return false;
                }
            }
        </script>
        <title>Jawaban Soal</title>
        <!-- Custom fonts for this template -->
        <link href="<?php echo base_url()?>assets/bootstrap/all.min.css" rel="stylesheet" type="text/css">
        <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

        <!-- Custom styles for this template -->
        <link href="<?php echo base_url()?>assets/bootstrap/sb-admin-2.min.css" rel="stylesheet">
    </head>
    <body>
    
    <center>
    <div class="card-body">
        <p>
            Silahkan Pilih Kategori
        </p>
            <div class="box-body">
                <select name = "category" id = "category" class = "select-selection__rendered">
                    <option value = 0>-- Category -- </option>
                    <?php foreach ($categoryData->result() as $row){
                    ?>
                        <option value = <?php echo $row->idCategory;?>> <?php echo $row->nameCategory; ?></option>
                    <?php
                    } 
                    ?>
                </select>
            </div>
            <p>
            <div class="box-footer">
                <button id="addRow" class="btn-block btn-primary" onclick="get_dataReport()">Add Row</button>
            </div>
            </p>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="myTable" width="100%" cellspacing="0">
                <thead>
                <tr>
                        <th>Jenis</th>
                        <th>YM</th>
                        <th colspan = "6">Stock Awal</th>
                        <th colspan = "6">Stock In Beli</th>
                        <th colspan = "6">Stock In Buyback</th>
                        <th colspan = "6">Stock Out Penjualan</th>
                        <th colspan = "6">Stock Akhir</th>
                    </tr>
                    <tr>
                        <th>Jenis</th>
                        <th>YM</th>
                        <th>PCS</th>
                        <th>CARAT</th>
                        <th>GRAM</th>
                        <th>COGM</th>
                        <th>NET</th>
                        <th>USERNET</th>
                        <th>PCS</th>
                        <th>CARAT</th>
                        <th>GRAM</th>
                        <th>COGM</th>
                        <th>NET</th>
                        <th>USERNET</th>
                        <th>PCS</th>
                        <th>CARAT</th>
                        <th>GRAM</th>
                        <th>COGM</th>
                        <th>NET</th>
                        <th>USERNET</th>
                        <th>PCS</th>
                        <th>CARAT</th>
                        <th>GRAM</th>
                        <th>COGM</th>
                        <th>NET</th>
                        <th>USERNET</th>
                        <th>PCS</th>
                        <th>CARAT</th>
                        <th>GRAM</th>
                        <th>COGM</th>
                        <th>NET</th>
                        <th>USERNET</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Total</th>
                        <th>2023-07</th>
                        <th id="pcsSATotal"></th>
                        <th id="caratSATotal"></th>
                        <th id="gramSATotal"></th>
                        <th id="cogmSATotal"></th>
                        <th id="netSATotal"></th>
                        <th id="usernetSATotal"></th>
                        <th id="pcsSIBTotal"></th>
                        <th id="caratSIBTotal"></th>
                        <th id="gramSIBTotal"></th>
                        <th id="cogmSIBTotal"></th>
                        <th id="netSIBTotal"></th>
                        <th id="usernetSIBTotal"></th>
                        <th id="pcsSIBBTotal"></th>
                        <th id="caratSIBBTotal"></th>
                        <th id="gramSIBBTotal"></th>
                        <th id="cogmSIBBTotal"></th>
                        <th id="netSIBBTotal"></th>
                        <th id="usernetSIBBTotal"></th>
                        <th id="pcsSOPTotal"></th>
                        <th id="caratSOPTotal"></th>
                        <th id="gramSOPTotal"></th>
                        <th id="cogmSOPTotal"></th>
                        <th id="netSOPTotal"></th>
                        <th id="usernetSOPTotal"></th>
                        <th id="pcsAkhirTotal"></th>
                        <th id="caratAkhirTotal"></th>
                        <th id="gramAkhirTotal"></th>
                        <th id="cogmAkhirTotal"></th>
                        <th id="netAkhirTotal"></th>
                        <th id="usernetAkhirTotal"></th>
                    </tr>
                </tfoot>
                <tbody>
                    <tr></tr>
                </tbody>
            </table>
        </div>
    </div>
    <center>
        <!-- Bootstrap core JavaScript-->
        <script src="<?php echo base_url()?>assets/jquery/jquery.js"></script>
        <script src="<?php echo base_url()?>assets/bootstrap/js/bootstrap.bundle.min.js"></script>
        <!-- JavaScript Process For Add More-->
        <script src="<?php echo base_url()?>assets/js/proccess.js"></script>
        <!-- Core plugin JavaScript-->
        <script src="<?php echo base_url()?>assets/jquery-easing/jquery.easing.min.js"></script>
    </body>
</html>