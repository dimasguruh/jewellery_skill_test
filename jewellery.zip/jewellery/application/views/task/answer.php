<html>
    <head>
        <title>Jawaban Soal</title>
        <!-- Custom fonts for this template -->
        <link href="<?php echo base_url()?>assets/bootstrap/all.min.css" rel="stylesheet" type="text/css">
        <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

        <!-- Custom styles for this template -->
        <link href="<?php echo base_url()?>assets/bootstrap/sb-admin-2.min.css" rel="stylesheet">

        <!-- Custom styles for this page -->
        <!-- <link href="<?php echo base_url()?>assets/datatables/dataTables.bootstrap4.min.css" rel="stylesheet"> -->

    </head>
    <body>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="myTable" width="100%" cellspacing="0">
                <thead>
                <tr>
                        <th>Jenis</th>
                        <th>YM</th>
                        <th colspan = "6">Stock Awal</th>
                        <th colspan = "6">Stock In Beli</th>
                        <th colspan = "6">Stock In Buyback</th>
                        <th colspan = "6">Stock Out Penjualan</th>
                        <th colspan = "6">Stock Akhir</th>
                    </tr>
                    <tr>
                        <th>Jenis</th>
                        <th>YM</th>
                        <th>PCS</th>
                        <th>CARAT</th>
                        <th>GRAM</th>
                        <th>COGM</th>
                        <th>NET</th>
                        <th>USERNET</th>
                        <th>PCS</th>
                        <th>CARAT</th>
                        <th>GRAM</th>
                        <th>COGM</th>
                        <th>NET</th>
                        <th>USERNET</th>
                        <th>PCS</th>
                        <th>CARAT</th>
                        <th>GRAM</th>
                        <th>COGM</th>
                        <th>NET</th>
                        <th>USERNET</th>
                        <th>PCS</th>
                        <th>CARAT</th>
                        <th>GRAM</th>
                        <th>COGM</th>
                        <th>NET</th>
                        <th>USERNET</th>
                        <th>PCS</th>
                        <th>CARAT</th>
                        <th>GRAM</th>
                        <th>COGM</th>
                        <th>NET</th>
                        <th>USERNET</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Total</th>
                        <th>2023-07</th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php foreach($reportData->result() as $row){
                    ?>
                        <tr>
                            <td><?php echo $categoryName;?></td>
                            <td>2023-07</td>
                            <td><?php echo $row-> pcsSA;?></td>
                            <td><?php echo $row-> caratSA;?></td>
                            <td><?php echo $row-> gramSA;?></td>
                            <td><?php echo $row-> cogmSA;?></td>
                            <td><?php echo $row-> netSA;?></td>
                            <td><?php echo $row-> usernetSA;?></td>
                            <td><?php echo $row-> pcsSIB;?></td>
                            <td><?php echo $row-> caratSIB;?></td>
                            <td><?php echo $row-> gramSIB;?></td>
                            <td><?php echo $row-> cogmSIB;?></td>
                            <td><?php echo $row-> netSIB;?></td>
                            <td><?php echo $row-> usernetSIB;?></td>
                            <td><?php echo $row-> pcsSIBB;?></td>
                            <td><?php echo $row-> caratSIBB;?></td>
                            <td><?php echo $row-> gramSIBB;?></td>
                            <td><?php echo $row-> cogmSIBB;?></td>
                            <td><?php echo $row-> netSIBB;?></td>
                            <td><?php echo $row-> usernetSIBB;?></td>
                            <td><?php echo $row-> pcsSOP;?></td>
                            <td><?php echo $row-> caratSOP;?></td>
                            <td><?php echo $row-> gramSOP;?></td>
                            <td><?php echo $row-> cogmSOP;?></td>
                            <td><?php echo $row-> netSOP;?></td>
                            <td><?php echo $row-> usernetSOP;?></td>
                            <td><?php echo $row-> pcsAkhir;?></td>
                            <td><?php echo $row-> caratAkhir;?></td>
                            <td><?php echo $row-> gramAkhir;?></td>
                            <td><?php echo $row-> cogmAkhir;?></td>
                            <td><?php echo $row-> netAkhir;?></td>
                            <td><?php echo $row-> usernetAkhir;?></td>
                            <td></td> 
                        </tr>
                    <?php
                    }
                        ?>
                </tbody>
            </table>
        </div>
    </div>
    <button id="addRow">Add Row</button>


        <!-- Bootstrap core JavaScript-->
        <script src="<?php echo base_url()?>assets/jquery/jquery.min.js"></script>
        <script src="<?php echo base_url()?>assets/bootstrap/js/bootstrap.bundle.min.js"></script>
        <!-- JavaScript Process For Add More-->
        <script src="<?php echo base_url()?>assets/js/proccess.js"></script>
        <!-- Core plugin JavaScript-->
        <script src="<?php echo base_url()?>assets/jquery-easing/jquery.easing.min.js"></script>

        <!-- Custom scripts for all pages
        <script src="js/sb-admin-2.min.js"></script> -->

        <!-- Page level plugins -->
        <!-- <script src="<?php echo base_url()?>assets/datatables/jquery.dataTables.min.js"></script>
        <script src="<?php echo base_url()?>assets/datatables/dataTables.bootstrap4.min.js"></script> -->
    </body>
</html>