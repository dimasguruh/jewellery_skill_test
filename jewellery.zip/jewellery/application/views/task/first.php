<!DOCTYPE html>
<html>
<head>
	<title>Welcome</title>
</head>
<body>

<h2><center>Selamat Datang Di Lembar Kerja Skill Test</center></h2>
<h4><center>Guruh Sarwono - Senior Software Engineer</center></h4>
<p></p>
<br><br><br>
<h4><center><a href = "<?php echo base_url('task/workpage')?>">Lihat Hasil Kerja</center></h4>
</body>
</html>