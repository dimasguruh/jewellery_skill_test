<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Task_model extends CI_Model
{

    public function get_categoryReport()
    {
        $query = $this->db->query("SELECT * FROM category");
        return $query;
    }
    public function get_dataReport($id)
    {
        $queryParam = $this->db->query("SELECT * FROM category WHERE idCategory = $id");
        foreach($queryParam->result() as $row)
        {
            $type = $row->type;
            $condition = $row->condition;
        }

        if($type == "LS"){
            $query = $this->db->query("SELECT COUNT(pls.code) AS pcsSA, SUM(pls.weight) AS caratSA, 0 AS gramSA, SUM(pls.pricenet)AS cogmSA , SUM(pls.pricenet) AS netSA, SUM(pls.priceusr) AS usernetSA,  
            ifnull(COUNT(bbls.code),0) AS pcsSIB, ifnull(SUM(bbls.weight),0) AS caratSIB, 0 AS gramSIB, ifnull(SUM(bbls.pricenet),0)AS cogmSIB , ifnull(SUM(bbls.pricenet),0) AS netSIB, ifnull(SUM(bbls.priceusr),0) AS usernetSIB,
            0 AS pcsSIBB, 0 AS caratSIBB, 0 AS gramSIBB, 0 AS cogmSIBB, 0 AS netSIBB, 0 AS usernetSIBB,
            ifnull(COUNT(sl.id),0) AS pcsSOP, ifnull(SUM(sl.weight),0) AS caratSOP, 0 AS gramSOP, ifnull(SUM(sl.pricenet),0) AS cogmSOP, ifnull(SUM(sl.pricenet),0)AS netSOP, ifnull(SUM(sl.priceusr),0) AS usernetSOP,
            ifnull(COUNT(pls.code),0)+ifnull(COUNT(bbls.code),0)+0-ifnull(COUNT(sl.id),0) AS pcsAkhir, ifnull(SUM(pls.weight),0)+ ifnull(SUM(bbls.weight),0)+0-ifnull(SUM(sl.weight),0) AS caratAkhir, 0 AS gramAkhir,
            ifnull(SUM(pls.pricenet),0)+ifnull(SUM(bbls.pricenet),0)+0-ifnull(SUM(sl.pricenet),0) AS cogmAkhir, ifnull(SUM(pls.pricenet),0)+ifnull(SUM(bbls.pricenet),0)+0-ifnull(SUM(sl.pricenet),0) AS netAkhir, ifnull(SUM(pls.priceusr),0) + ifnull(SUM(bbls.pricenet),0) + 0 - ifnull(SUM(sl.priceusr),0) AS usernetAkhir
            FROM `product-ls` pls
            INNER JOIN `stock-awal-ls` sal
            ON pls.code = sal.code
            LEFT JOIN `buyback-ls` bbls
            ON pls.code = bbls.code
            LEFT JOIN `sales-ls` sl
            ON pls.id = sl.id
            $condition");
        } else{
            $query = $this->db->query("SELECT IFNULL(COUNT(pdj.code),0) AS pcsSA, IFNULL(SUM(pdj.weightg),0) AS caratSA, IFNULL(SUM(pdj.weightm),0) AS gramSA, IFNULL(SUM(pdj.cogm),0) AS cogmSA, IFNULL(SUM(pdj.pricenet),0) AS netSA, IFNULL(SUM(pdj.priceusr),0) AS usernetSA,
            IFNULL(COUNT(bdj.code),0) AS pcsSIB, IFNULL(SUM(bdj.weightg),0) AS caratSIB, IFNULL(SUM(bdj.weightm),0) AS gramSIB, IFNULL(SUM(bdj.cogm),0) AS cogmSIB, IFNULL(SUM(bdj.pricenet),0) AS netSIB, IFNULL(SUM(bdj.priceusr),0) AS usernetSIB,
            IFNULL(COUNT(bbdj.code),0) AS pcsSIBB, IFNULL(SUM(bbdj.weightg),0) AS caratSIBB, IFNULL(SUM(bbdj.weightm),0) AS gramSIBB, IFNULL(SUM(bbdj.cogm),0) AS cogmSIBB, IFNULL(SUM(bbdj.pricenet),0) AS netSIBB, IFNULL(SUM(bbdj.priceusr),0) AS usernetSIBB,
            IFNULL(COUNT(sl.code),0) AS pcsSOP, IFNULL(SUM(sl.weightg),0) AS caratSOP, IFNULL(SUM(sl.weightm),0) AS gramSOP, IFNULL(SUM(sl.cogm),0) AS cogmSOP, IFNULL(SUM(sl.pricenet),0) AS netSOP, IFNULL(SUM(sl.priceusr),0) AS usernetSOP,
            ifnull(COUNT(pdj.code),0)+ifnull(COUNT(bdj.code),0)+ifnull(COUNT(bbdj.code),0)+0-ifnull(COUNT(sl.id),0) AS pcsAkhir, ifnull(SUM(pdj.weightg),0)+ ifnull(SUM(bdj.weightg),0) + ifnull(SUM(bbdj.weightg),0)+0-ifnull(SUM(sl.weightg),0) AS caratAkhir, ifnull(SUM(pdj.weightm),0)+ ifnull(SUM(bdj.weightm),0) + ifnull(SUM(bbdj.weightm),0)+0-ifnull(SUM(sl.weightm),0) AS gramAkhir,
            ifnull(SUM(pdj.pricenet),0)+ifnull(SUM(bbdj.pricenet),0)+0-ifnull(SUM(sl.pricenet),0) AS cogmAkhir, ifnull(SUM(pdj.pricenet),0)+ifnull(SUM(bbdj.pricenet),0)+0-ifnull(SUM(sl.pricenet),0) AS netAkhir, ifnull(SUM(pdj.priceusr),0) + ifnull(SUM(bbdj.pricenet),0) + 0 - ifnull(SUM(sl.priceusr),0) AS usernetAkhir
            FROM `product-dj` pdj
            INNER JOIN `stock-awal-dj` sad
            ON pdj.code = sad.code
            LEFT JOIN (SELECT bdj.code, bdj.weightm, bdj.weightg, bdj.cogm, bdj.pricenet, bdj.priceusr FROM `buyback-dj` bdj
            WHERE bdj.isproduction = 0) bdj
            ON pdj.code = bdj.code
            LEFT JOIN (SELECT bbdj.code, bbdj.weightm, bbdj.weightg, bbdj.cogm, bbdj.pricenet, bbdj.priceusr FROM `buyback-dj` bbdj
            WHERE bbdj.isproduction = 1) bbdj
            ON pdj.code = bbdj.code
            LEFT JOIN `sales-dj` sl
            ON pdj.code = sl.code
            $condition");
        }
        return $query;
    }

    public function getCategoryName($id)
    {
        $queryParam = $this->db->query("SELECT * FROM category WHERE idCategory = $id");
        // foreach($queryParam->result() as $row){
        //     $category = $row->nameCategory;
        // }
        return $queryParam;
    }

    public function tes($id)
    {
        $queryParam = $this->db->query("SELECT * FROM category WHERE idCategory = $id");
        foreach($queryParam->result() as $row)
        {
            $type = $row->type;
            $condition = $row->condition;
        }
        return $condition;
    }
}