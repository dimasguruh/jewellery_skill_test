<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Task extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		$this->load->model('Task_model');
	}

    public function Index()
    {
        $this->load->view('task/first');
    }

    public function workpage()
    {
        $this->load->view('task/soal');
    }

    public function answerFilter()
    {
        $val['categoryData'] = $this->Task_model->get_categoryReport();
        $this->load->view('task/answerFilter' ,$val);
    }

    public function answer()
    {
        //$id = $this->input->post('category');
        $id = $this->uri->segment(3);
        $valCategoryName = $this->Task_model->getCategoryName($id);
        $value = $this->Task_model->get_dataReport($id);
        //$twovar = array('categoryName' => $valCategoryName->result(), 'reportData' => $value->result());
        $twovar = array_merge($valCategoryName->result(), $value->result());
        echo json_encode($twovar);
    }
}