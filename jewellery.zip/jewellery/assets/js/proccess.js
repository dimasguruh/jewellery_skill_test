function get_dataReport(){
    var dt;
    var category = document.getElementById('category').value;
    let categoryName;
    if(category == 1)
    {
      categoryName = "LS Generic";
    }else if(category == 2){
      categoryName = "LS Dossier";
    }else if(category == 3){
      categoryName = "LS Branded";
    }else if(category == 4){
      categoryName = "LS Gemstone";
    }else if(category == 5){
      categoryName = "DJ Produksi";
    }else if(category == 6){
      categoryName = "DJ + GS Produksi";
    }else if(category == 7){
      categoryName = "DD Produksi";
    }else if(category == 8){
      categoryName = "DJ + BD Produksi";
    }else if(category == 9){
      categoryName = "DJ Beli";
    }else if(category == 10){
      categoryName = "DJ + GS Beli";
    }else if(category == 11){
      categoryName = "DD Beli";
    }else if(category == 12){
      categoryName = "DJ + BD Beli";
    }else{
      alert("Anda Belum Memilih Kategori");
      return false;
    }
    var number = localStorage.getItem("numberStore");
    if(number === null){
      number = 0;
    }
    var numberInt = parseInt(number,10);
    numberInt+=1;
    localStorage.setItem("numberStore", numberInt);

    //Input All Variable To Local Storage

    var pcsSA = localStorage.getItem("pcsSA");
    if(pcsSA === null){
      pcsSA = 0;
    }
    var pcsSAInt = parseInt(pcsSA,10);
    var caratSA = localStorage.getItem("caratSA");
    if(caratSA === null){
      caratSA = 0;
    }
    var caratSAInt = parseInt(caratSA,10);
    var gramSA = localStorage.getItem("gramSA");
    if(gramSA === null){
      gramSA = 0;
    }
    var gramSAInt = parseInt(gramSA,10);
    var cogmSA = localStorage.getItem("cogmSA");
    if(cogmSA === null){
      cogmSA = 0;
    }
    var cogmSAInt = parseInt(cogmSA,10);
    var netSA = localStorage.getItem("netSA");
    if(netSA === null){
      netSA = 0;
    }
    var netSAInt = parseInt(netSA,10);
    var usernetSA = localStorage.getItem("usernetSA");
    if(usernetSA === null){
      usernetSA = 0;
    }
    var usernetSAInt = parseInt(usernetSA,10);
    var pcsSIB = localStorage.getItem("pcsSIB");
    if(pcsSIB === null){
      pcsSIB = 0;
    }

    var pcsSIBInt = parseInt(pcsSIB,10);
    var caratSIB = localStorage.getItem("caratSIB");
    if(caratSIB === null){
      caratSIB = 0;
    }
    var caratSIBInt = parseInt(caratSIB,10);
    var gramSIB = localStorage.getItem("gramSIB");
    if(gramSIB === null){
      gramSIB = 0;
    }
    var gramSIBInt = parseInt(gramSIB,10);
    var cogmSIB = localStorage.getItem("cogmSIB");
    if(cogmSIB === null){
      cogmSIB = 0;
    }
    var cogmSIBInt = parseInt(cogmSIB,10);
    var netSIB = localStorage.getItem("netSIB");
    if(netSIB === null){
      netSIB = 0;
    }
    var netSIBInt = parseInt(netSIB,10);
    var usernetSIB = localStorage.getItem("usernetSIB");
    if(usernetSIB === null){
      usernetSIB = 0;
    }
    var usernetSIBInt = parseInt(usernetSIB,10);
    var pcsSIBB = localStorage.getItem("pcsSIBB");
    if(pcsSIBB === null){
      pcsSIBB = 0;
    }
    var pcsSIBBInt = parseInt(pcsSIBB,10);
    var caratSIBB = localStorage.getItem("caratSIBB");
    if(caratSIBB === null){
      caratSIBB = 0;
    }
    var caratSIBBInt = parseInt(caratSIBB,10);
    var gramSIBB = localStorage.getItem("gramSIBB");
    if(gramSIBB === null){
      gramSIBB = 0;
    }
    var gramSIBBInt = parseInt(gramSIBB,10);
    var cogmSIBB = localStorage.getItem("cogmSIBB");
    if(cogmSIBB === null){
      cogmSIBB = 0;
    }
    var cogmSIBBInt = parseInt(cogmSIBB,10);
    var netSIBB = localStorage.getItem("netSIBB");
    if(netSIBB === null){
      netSIBB = 0;
    }
    var netSIBBInt = parseInt(netSIBB,10);
    var usernetSIBB = localStorage.getItem("usernetSIBB");
    if(usernetSIBB === null){
      usernetSIBB = 0;
    }
    var usernetSIBBInt = parseInt(usernetSIBB,10);

    var pcsSOP = localStorage.getItem("pcsSOP");
    if(pcsSOP === null){
      pcsSOP = 0;
    }
    var pcsSOPInt = parseInt(pcsSOP,10);
    var caratSOP = localStorage.getItem("caratSOP");
    if(caratSOP === null){
      caratSOP = 0;
    }
    var caratSOPInt = parseInt(caratSOP,10);
    var gramSOP = localStorage.getItem("gramSOP");
    if(gramSOP === null){
      gramSOP = 0;
    }
    var gramSOPInt = parseInt(gramSOP,10);
    var cogmSOP = localStorage.getItem("cogmSOP");
    if(cogmSOP === null){
      cogmSOP = 0;
    }
    var cogmSOPInt = parseInt(cogmSOP,10);
    var netSOP = localStorage.getItem("netSOP");
    if(netSOP === null){
      netSOP = 0;
    }
    var netSOPInt = parseInt(netSOP,10);
    var usernetSOP = localStorage.getItem("usernetSOP");
    if(usernetSOP === null){
      usernetSOP = 0;
    }
    var usernetSOPInt = parseInt(usernetSOP,10);

    var pcsAkhir = localStorage.getItem("pcsAkhir");
    if(pcsAkhir === null){
      pcsAkhir = 0;
    }
    var pcsAkhirInt = parseInt(pcsAkhir,10);
    var caratAkhir = localStorage.getItem("caratAkhir");
    if(caratAkhir === null){
      caratAkhir = 0;
    }
    var caratAkhirInt = parseInt(caratAkhir,10);
    var gramAkhir = localStorage.getItem("gramAkhir");
    if(gramAkhir === null){
      gramAkhir = 0;
    }
    var gramAkhirInt = parseInt(gramAkhir,10);
    var cogmAkhir = localStorage.getItem("cogmAkhir");
    if(cogmAkhir === null){
      cogmAkhir = 0;
    }
    var cogmAkhirInt = parseInt(cogmAkhir,10);
    var netAkhir = localStorage.getItem("netAkhir");
    if(netAkhir === null){
      netAkhir = 0;
    }
    var netAkhirInt = parseInt(netAkhir,10);
    var usernetAkhir = localStorage.getItem("usernetAkhir");
    if(usernetAkhir === null){
      usernetAkhir = 0;
    }
    var usernetAkhirInt = parseInt(usernetAkhir,10);

    $.ajax({
      url : "answer/"+category,
      success : function(data){
        $.each(data,function(index,row){
          console.log(categoryName);
          //var categoryName = row.nameCategory; Can't get data category from parsing
          dt = '<tr><td>'+ categoryName + '</td><td>' +'2023-07'+ '</td>'+'<td>'+ row.pcsSA +'</td><td>'+ row.caratSA +'</td><td>'+ row.gramSA +'</td><td>'+ row.cogmSA +'</td><td>'+ row.netSA +'</td><td>'+ row.usernetSA +'</td><td>'+ row.pcsSIB +'</td><td>'+ row.caratSIB +'</td><td>'+ row.gramSIB +'</td><td>'+ row.cogmSIB +'</td><td>'+ row.netSIB +'</td><td>'+ row.usernetSIB +'</td>'
          +'<td>'+ row.pcsSIBB +'</td><td>'+ row.caratSIBB+'</td><td>'+ row.gramSIBB +'</td><td>'+ row.cogmSIBB +'</td><td>'+ row.netSIBB +'</td><td>'+ row.usernetSIBB +'</td><td>'+ row.pcsSOP +'</td><td>'+ row.caratSOP+'</td><td>'+ row.gramSOP +'</td><td>'+ row.cogmSOP +'</td><td>'+ row.netSOP +'</td><td>'+ row.usernetSOP +'</td>'
          +'<td>'+ row.pcsAkhir +'</td><td>'+ row.caratAkhir+'</td><td>'+ row.gramAkhir +'</td><td>'+ row.cogmAkhir +'</td><td>'+ row.netAkhir +'</td><td>'+ row.usernetAkhir +'</td>'
          
          // Add Row Result to Temp Memmory
          pcsSAres = parseInt(row.pcsSA,10) + pcsSAInt;
          localStorage.setItem("pcsSA", pcsSAres);
          caratSAres = parseInt(row.caratSA,10) + caratSAInt;
          localStorage.setItem("caratSA", caratSAres);
          gramSAres = parseInt(row.gramSA,10) + gramSAInt;
          localStorage.setItem("gramSA", gramSAres);
          cogmSAres = parseInt(row.cogmSA,10) + cogmSAInt;
          localStorage.setItem("cogmSA", cogmSAres);
          netSAres = parseInt(row.netSA,10) + netSAInt;
          localStorage.setItem("netSA", netSAres);
          usernetSAres = parseInt(row.usernetSA,10) + usernetSAInt;
          localStorage.setItem("usernetSA", usernetSAres);
          pcsSIBres = parseInt(row.pcsSIB,10) + pcsSIBInt;
          localStorage.setItem("pcsSIB", pcsSIBres);
          caratSIBres = parseInt(row.caratSIB,10) + caratSIBInt;
          localStorage.setItem("caratSIB", caratSIBres);
          gramSIBres = parseInt(row.gramSIB,10) + gramSIBInt;
          localStorage.setItem("gramSIB", gramSIBres);
          cogmSIBres = parseInt(row.cogmSIB,10) + cogmSIBInt;
          localStorage.setItem("cogmSIB", cogmSIBres);
          netSIBres = parseInt(row.netSIB,10) + netSIBInt;
          localStorage.setItem("netSIB", netSIBres);
          usernetSIBres = parseInt(row.usernetSIB,10) + usernetSIBInt;
          localStorage.setItem("usernetSIB", usernetSIBres);
          pcsSIBBres = parseInt(row.pcsSIBB,10) + pcsSIBBInt;
          localStorage.setItem("pcsSIBB", pcsSIBBres);
          caratSIBBres = parseInt(row.caratSIBB,10) + caratSIBBInt;
          localStorage.setItem("caratSIBB", caratSIBBres);
          gramSIBBres = parseInt(row.gramSIBB,10) + gramSIBBInt;
          localStorage.setItem("gramSIBB", gramSIBBres);
          cogmSIBBres = parseInt(row.cogmSIBB,10) + cogmSIBBInt;
          localStorage.setItem("cogmSIBB", cogmSIBBres);
          netSIBBres = parseInt(row.netSIBB,10) + netSIBBInt;
          localStorage.setItem("netSIBB", netSIBBres);
          usernetSIBBres = parseInt(row.usernetSIBB,10) + usernetSIBBInt;
          localStorage.setItem("usernetSIBB", usernetSIBBres);
          pcsSOPres = parseInt(row.pcsSOP,10) + pcsSOPInt;
          localStorage.setItem("pcsSOP", pcsSOPres);
          caratSOPres = parseInt(row.caratSOP,10) + caratSOPInt;
          localStorage.setItem("caratSOP", caratSOPres);
          gramSOPres = parseInt(row.gramSOP,10) + gramSOPInt;
          localStorage.setItem("gramSOP", gramSOPres);
          cogmSOPres = parseInt(row.cogmSOP,10) + cogmSOPInt;
          localStorage.setItem("cogmSOP", cogmSOPres);
          netSOPres = parseInt(row.netSOP,10) + netSOPInt;
          localStorage.setItem("netSOP", netSOPres);
          usernetSOPres = parseInt(row.usernetSOP,10) + usernetSOPInt;
          localStorage.setItem("usernetSOP", usernetSOPres);
          pcsAkhirres = parseInt(row.pcsAkhir,10) + pcsAkhirInt;
          localStorage.setItem("pcsAkhir", pcsAkhirres);
          caratAkhirres = parseInt(row.caratAkhir,10) + caratAkhirInt;
          localStorage.setItem("caratAkhir", caratAkhirres);
          gramAkhirres = parseInt(row.gramAkhir,10) + gramAkhirInt;
          localStorage.setItem("gramAkhir", gramAkhirres);
          cogmAkhirres = parseInt(row.cogmAkhir,10) + cogmAkhirInt;
          localStorage.setItem("cogmAkhir", cogmAkhirres);
          netAkhirres = parseInt(row.netAkhir,10) + netAkhirInt;
          localStorage.setItem("netAkhir", netAkhirres);
          usernetAkhirres = parseInt(row.usernetAkhir,10) + usernetAkhirInt;
          localStorage.setItem("usernetAkhir", usernetAkhirres);
        })
        document.getElementById("myTable").insertAdjacentHTML('beforeend', dt);
        countTotal();
      },
      dataType : 'JSON'
    });
}

window.onload = function(){
  //Remove Temp Memory
  localStorage.removeItem("numberStore");
  localStorage.removeItem("pcsSA");
  localStorage.removeItem("caratSA");
  localStorage.removeItem("gramSA");
  localStorage.removeItem("cogmSA");
  localStorage.removeItem("netSA");
  localStorage.removeItem("usernetSA");
  localStorage.removeItem("numberStore");
  localStorage.removeItem("pcsSIB");
  localStorage.removeItem("caratSIB");
  localStorage.removeItem("gramSIB");
  localStorage.removeItem("cogmSIB");
  localStorage.removeItem("netSIB");
  localStorage.removeItem("usernetSIB");
  localStorage.removeItem("pcsSIBB");
  localStorage.removeItem("caratSIBB");
  localStorage.removeItem("gramSIBB");
  localStorage.removeItem("cogmSIBB");
  localStorage.removeItem("netSIBB");
  localStorage.removeItem("usernetSIBB");
  localStorage.removeItem("pcsSOP");
  localStorage.removeItem("caratSOP");
  localStorage.removeItem("gramSOP");
  localStorage.removeItem("cogmSOP");
  localStorage.removeItem("netSOP");
  localStorage.removeItem("usernetSOP");
  localStorage.removeItem("pcsAkhir");
  localStorage.removeItem("caratAkhir");
  localStorage.removeItem("gramAkhir");
  localStorage.removeItem("cogmAkhir");
  localStorage.removeItem("netAkhir");
  localStorage.removeItem("usernetAkhir");
}

function countTotal()
{
  //Load Into HTML
  var pcsSA = localStorage.getItem("pcsSA");
  document.getElementById('pcsSATotal').innerHTML = pcsSA;
  var caratSA = localStorage.getItem("caratSA");
  document.getElementById('caratSATotal').innerHTML = caratSA;
  var gramSA = localStorage.getItem("gramSA");
  document.getElementById('gramSATotal').innerHTML = gramSA;
  var cogmSA = localStorage.getItem("cogmSA");
  document.getElementById('cogmSATotal').innerHTML = cogmSA;
  var netSA = localStorage.getItem("netSA");
  document.getElementById('netSATotal').innerHTML = netSA;
  var usernetSA = localStorage.getItem("usernetSA");
  document.getElementById('usernetSATotal').innerHTML = usernetSA;
  
  var pcsSIB = localStorage.getItem("pcsSIB");
  document.getElementById('pcsSIBTotal').innerHTML = pcsSIB;
  var caratSIB = localStorage.getItem("caratSIB");
  document.getElementById('caratSIBTotal').innerHTML = caratSIB;
  var gramSIB = localStorage.getItem("gramSIB");
  document.getElementById('gramSIBTotal').innerHTML = gramSIB;
  var cogmSIB = localStorage.getItem("cogmSIB");
  document.getElementById('cogmSIBTotal').innerHTML = cogmSIB;
  var netSIB = localStorage.getItem("netSIB");
  document.getElementById('netSIBTotal').innerHTML = netSIB;
  var usernetSIB = localStorage.getItem("usernetSIB");
  document.getElementById('usernetSIBTotal').innerHTML = usernetSIB;

  var pcsSIBB = localStorage.getItem("pcsSIBB");
  document.getElementById('pcsSIBBTotal').innerHTML = pcsSIBB;
  var caratSIBB = localStorage.getItem("caratSIBB");
  document.getElementById('caratSIBBTotal').innerHTML = caratSIBB;
  var gramSIBB = localStorage.getItem("gramSIBB");
  document.getElementById('gramSIBBTotal').innerHTML = gramSIBB;
  var cogmSIBB = localStorage.getItem("cogmSIBB");
  document.getElementById('cogmSIBBTotal').innerHTML = cogmSIBB;
  var netSIBB = localStorage.getItem("netSIBB");
  document.getElementById('netSIBBTotal').innerHTML = netSIBB;
  var usernetSIBB = localStorage.getItem("usernetSIBB");
  document.getElementById('usernetSIBBTotal').innerHTML = usernetSIBB;

  var pcsSOP = localStorage.getItem("pcsSOP");
  document.getElementById('pcsSOPTotal').innerHTML = pcsSOP;
  var caratSOP = localStorage.getItem("caratSOP");
  document.getElementById('caratSOPTotal').innerHTML = caratSOP;
  var gramSOP = localStorage.getItem("gramSOP");
  document.getElementById('gramSOPTotal').innerHTML = gramSOP;
  var cogmSOP = localStorage.getItem("cogmSOP");
  document.getElementById('cogmSOPTotal').innerHTML = cogmSOP;
  var netSOP = localStorage.getItem("netSOP");
  document.getElementById('netSOPTotal').innerHTML = netSOP;
  var usernetSOP = localStorage.getItem("usernetSOP");
  document.getElementById('usernetSOPTotal').innerHTML = usernetSOP;

  var pcsAkhir = localStorage.getItem("pcsAkhir");
  document.getElementById('pcsAkhirTotal').innerHTML = pcsAkhir;
  var caratAkhir = localStorage.getItem("caratAkhir");
  document.getElementById('caratAkhirTotal').innerHTML = caratAkhir;
  var gramAkhir = localStorage.getItem("gramAkhir");
  document.getElementById('gramAkhirTotal').innerHTML = gramAkhir;
  var cogmAkhir = localStorage.getItem("cogmAkhir");
  document.getElementById('cogmAkhirTotal').innerHTML = cogmAkhir;
  var netAkhir = localStorage.getItem("netAkhir");
  document.getElementById('netAkhirTotal').innerHTML = netAkhir;
  var usernetAkhir = localStorage.getItem("usernetAkhir");
  document.getElementById('usernetAkhirTotal').innerHTML = usernetAkhir;
}